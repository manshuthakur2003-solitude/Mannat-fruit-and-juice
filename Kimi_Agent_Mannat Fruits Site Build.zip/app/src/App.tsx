import './App.css';
import Header from './sections/Header';
import Hero from './sections/Hero';
import About from './sections/About';
import Rooms from './sections/Rooms';
import Thalis from './sections/Thalis';
import Menu from './sections/Menu';
import Gallery from './sections/Gallery';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <Hero />
        <About />
        <Rooms />
        <Thalis />
        <Menu />
        <Gallery />
      </main>
      <Footer />
    </div>
  );
}

export default App;
