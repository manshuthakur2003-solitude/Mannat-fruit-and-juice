import { MapPin, Clock, Phone, Award, Leaf, Shield, Star } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: Leaf,
      title: '100% Pure Veg',
      description: 'Authentic vegetarian cuisine prepared with care',
    },
    {
      icon: Award,
      title: 'Quality Ingredients',
      description: 'MDH Masala & Fortune Oil only',
    },
    {
      icon: Shield,
      title: 'Hygiene First',
      description: 'Clean kitchen & dining area',
    },
    {
      icon: Star,
      title: 'Highway Location',
      description: 'Easy access on NH-44',
    },
  ];

  return (
    <section id="about" className="relative py-20 lg:py-28 bg-gradient-to-b from-gray-900 to-black overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 50px, rgba(255,255,255,.03) 50px, rgba(255,255,255,.03) 51px)'
        }} />
      </div>

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Content */}
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full mb-6">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-yellow-400 text-sm font-medium uppercase tracking-wider">
                  About Us
                </span>
              </div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
                Welcome to <span className="text-yellow-400">Mannat</span>
              </h2>

              <p className="text-gray-300 text-lg leading-relaxed mb-6">
                Located on the bustling NH-44 at Nangal Kheri, Panipat, Mannat Fruits & Juice 
                is your perfect stop for a delicious meal, refreshing juices, and a comfortable 
                stay. We pride ourselves on serving pure vegetarian food made with the finest 
                ingredients.
              </p>

              <p className="text-gray-400 leading-relaxed mb-8">
                Our unique selling point is our commitment to health – we use NO refined sugar 
                in our juices, only pure KHAAND (raw sugar) for a healthier, more natural taste. 
                Whether you're a highway traveler looking for a quick bite or need a comfortable 
                room for the night, we've got you covered.
              </p>

              {/* Contact Info */}
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-yellow-400/10 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-yellow-400" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Location</p>
                    <p className="text-white font-medium">NH-44, Nangal Kheri, Panipat – 132103</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Timings</p>
                    <p className="text-white font-medium">Open 24 Hours, 7 Days a Week</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                    <Phone className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Contact</p>
                    <p className="text-white font-medium">+91 96170 00044 | +91 89500 67275</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Content - Highlights */}
            <div className="grid sm:grid-cols-2 gap-4">
              {highlights.map((highlight, index) => (
                <div
                  key={index}
                  className="bg-gray-900/50 border border-white/10 rounded-2xl p-6 hover:border-yellow-400/50 transition-all duration-300 group"
                >
                  <div className="w-14 h-14 rounded-xl bg-yellow-400/10 flex items-center justify-center mb-4 group-hover:bg-yellow-400/20 transition-colors">
                    <highlight.icon className="w-7 h-7 text-yellow-400" />
                  </div>
                  <h3 className="text-white font-bold text-lg mb-2">{highlight.title}</h3>
                  <p className="text-gray-400 text-sm">{highlight.description}</p>
                </div>
              ))}

              {/* USP Card */}
              <div className="sm:col-span-2 bg-gradient-to-r from-green-600/20 to-green-800/20 border border-green-500/30 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
                    <Leaf className="w-7 h-7 text-green-500" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg mb-2">Our Promise</h3>
                    <p className="text-gray-300">
                      We use <span className="text-green-400 font-semibold">NO SUGAR</span> in our 
                      juices, only <span className="text-green-400 font-semibold">KHAAND (Raw Sugar)</span> for 
                      better health. Taste the difference of natural sweetness!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
