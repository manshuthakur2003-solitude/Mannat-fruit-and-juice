import { Star, Check, Flame } from 'lucide-react';

const Thalis = () => {
  const thalis = [
    {
      name: 'Special Thali',
      price: '₹151',
      icon: Star,
      color: 'from-yellow-500 to-orange-500',
      items: [
        'Dal Fry',
        'Mix Veg',
        '4 Butter Roti',
        'Rice',
        'Raita',
        'Salad',
      ],
    },
    {
      name: 'Deluxe Thali',
      price: '₹251',
      icon: Flame,
      color: 'from-orange-500 to-red-500',
      featured: true,
      items: [
        'Dal Makhani',
        'Shahi Paneer',
        '4 Butter Roti',
        'Rice',
        'Raita',
        'Salad',
      ],
    },
    {
      name: 'Mannat Special Thali',
      price: '₹351',
      icon: Star,
      color: 'from-red-500 to-pink-500',
      items: [
        'Dal Makhani',
        'Kadhai Paneer',
        '2 Butter Naan',
        '2 Butter Roti',
        'Jeera Rice',
        'Mix Raita',
        'Salad',
        'Milk Sweet',
      ],
    },
  ];

  return (
    <section id="thalis" className="relative py-20 lg:py-28 bg-black overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255,255,255,.05) 35px, rgba(255,255,255,.05) 70px)'
        }} />
      </div>

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-12 lg:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full mb-4">
            <Flame className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 text-sm font-medium uppercase tracking-wider">
              Most Popular
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Traveller's Choice – <span className="text-yellow-400">Special Thalis</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Authentic Indian vegetarian thalis, prepared with pure desi ghee and fresh ingredients
          </p>
        </div>

        {/* Thali Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {thalis.map((thali, index) => (
            <div
              key={index}
              className={`relative group ${thali.featured ? 'lg:-mt-4 lg:mb-4' : ''}`}
            >
              {/* Featured Badge */}
              {thali.featured && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-4 py-1 rounded-full text-sm font-bold">
                    MOST POPULAR
                  </div>
                </div>
              )}

              <div
                className={`relative h-full bg-gradient-to-b from-gray-900 to-black border ${
                  thali.featured
                    ? 'border-yellow-400 shadow-xl shadow-yellow-400/20'
                    : 'border-white/10 hover:border-yellow-400/50'
                } rounded-2xl overflow-hidden transition-all duration-300 group-hover:transform group-hover:scale-[1.02]`}
              >
                {/* Header */}
                <div className={`bg-gradient-to-r ${thali.color} p-6`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                        <thali.icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-white text-xl font-bold">{thali.name}</h3>
                    </div>
                  </div>
                  <div className="mt-4">
                    <span className="text-4xl sm:text-5xl font-bold text-white">{thali.price}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <ul className="space-y-3">
                    {thali.items.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 text-green-500" />
                        </div>
                        <span className="text-gray-300">{item}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <button
                    onClick={() => {
                      const element = document.querySelector('#contact');
                      if (element) element.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`w-full mt-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                      thali.featured
                        ? 'bg-yellow-400 text-black hover:bg-yellow-500'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                  >
                    Order Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Thali Image */}
        <div className="mt-12 lg:mt-16 max-w-4xl mx-auto">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-yellow-400/10">
            <img
              src="/images/thali-special.jpg"
              alt="Special Thali"
              className="w-full h-[250px] sm:h-[350px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <p className="text-white text-lg sm:text-xl font-semibold">
                Serving Hot & Fresh Thalis 24/7
              </p>
              <p className="text-gray-300 text-sm mt-1">
                Prepared with MDH Masala & Fortune Oil
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Thalis;
