import { Hotel, Check, Phone, Shield, Clock, Car, Wind } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Rooms = () => {
  const features = [
    { icon: Wind, text: 'AC Rooms' },
    { icon: Check, text: 'Attached Washroom' },
    { icon: Clock, text: '24/7 Service' },
    { icon: Car, text: 'Safe Parking' },
    { icon: Shield, text: 'Secure Stay' },
  ];

  return (
    <section id="rooms" className="relative py-20 lg:py-28 bg-gradient-to-b from-black via-gray-900 to-black overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full mb-4">
            <Hotel className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 text-sm font-medium uppercase tracking-wider">
              Rest & Recharge – Luxury Stay
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Deluxe AC Rooms for <span className="text-yellow-400">Highway Travelers</span>
          </h2>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Room Image */}
            <div className="relative group">
              <div className="relative overflow-hidden rounded-2xl shadow-2xl shadow-yellow-400/10">
                <img
                  src="/images/room-deluxe.jpg"
                  alt="Deluxe AC Room"
                  className="w-full h-[300px] sm:h-[400px] object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                
                {/* Price Tag Overlay */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-black/80 backdrop-blur-md rounded-xl p-4 border border-yellow-400/30">
                    <p className="text-gray-400 text-sm mb-1">Starting from</p>
                    <div className="flex items-baseline gap-1">
                      <span className="text-yellow-400 text-4xl sm:text-5xl font-bold">₹1000</span>
                      <span className="text-gray-400">/night</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-yellow-400/20 rounded-full blur-2xl" />
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-yellow-400/10 rounded-full blur-3xl" />
            </div>

            {/* Room Details */}
            <div className="space-y-6">
              {/* Price Highlight */}
              <div className="bg-gradient-to-r from-yellow-400/20 to-yellow-600/20 border-2 border-yellow-400 rounded-2xl p-6 sm:p-8 text-center lg:text-left">
                <p className="text-gray-300 text-sm uppercase tracking-wider mb-2">
                  Night Stay @ Just
                </p>
                <div className="flex items-center justify-center lg:justify-start gap-2">
                  <span className="text-5xl sm:text-6xl lg:text-7xl font-bold text-yellow-400">
                    ₹1000
                  </span>
                </div>
                <p className="text-gray-400 mt-2">Per room per night</p>
              </div>

              {/* Features Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {features.map((feature, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10 hover:border-yellow-400/50 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-lg bg-yellow-400/10 flex items-center justify-center flex-shrink-0">
                      <feature.icon className="w-5 h-5 text-yellow-400" />
                    </div>
                    <span className="text-white text-sm font-medium">{feature.text}</span>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href="tel:+919617000044"
                  className="flex-1"
                >
                  <Button
                    size="lg"
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-6 text-lg font-semibold rounded-xl"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    Call to Book: +91 96170 00044
                  </Button>
                </a>
              </div>

              {/* Additional Info */}
              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span>Instant Booking</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span>Clean & Hygienic</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span>Highway Location</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Rooms;
