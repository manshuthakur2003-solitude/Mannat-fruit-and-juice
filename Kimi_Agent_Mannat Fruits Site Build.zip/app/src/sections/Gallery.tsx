import { useState } from 'react';
import { X, ZoomIn, Hotel, UtensilsCrossed, Car, Sparkles } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryItems = [
    {
      src: '/images/gallery-1.jpg',
      title: 'Fresh Anar Juice',
      category: 'Juices',
      icon: UtensilsCrossed,
    },
    {
      src: '/images/gallery-2.jpg',
      title: 'Kaju Milk Shake',
      category: 'Shakes',
      icon: UtensilsCrossed,
    },
    {
      src: '/images/gallery-3.jpg',
      title: 'Paneer Kadhai',
      category: 'Main Course',
      icon: UtensilsCrossed,
    },
    {
      src: '/images/room-deluxe.jpg',
      title: 'Deluxe AC Room',
      category: 'Rooms',
      icon: Hotel,
    },
    {
      src: '/images/gallery-4.jpg',
      title: 'Clean Washroom',
      category: 'Rooms',
      icon: Hotel,
    },
    {
      src: '/images/gallery-5.jpg',
      title: 'Banana Shake',
      category: 'Shakes',
      icon: UtensilsCrossed,
    },
    {
      src: '/images/gallery-6.jpg',
      title: 'Veg Fried Momos',
      category: 'Fast Food',
      icon: UtensilsCrossed,
    },
    {
      src: '/images/parking.jpg',
      title: 'Safe Parking',
      category: 'Parking',
      icon: Car,
    },
    {
      src: '/images/thali-special.jpg',
      title: 'Special Thali',
      category: 'Thalis',
      icon: UtensilsCrossed,
    },
  ];

  return (
    <section id="gallery" className="relative py-20 lg:py-28 bg-black overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/30 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 text-sm font-medium uppercase tracking-wider">
              Visual Tour
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Our <span className="text-yellow-400">Gallery</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Take a look at our delicious food, comfortable rooms, and facilities
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
          {galleryItems.map((item, index) => (
            <div
              key={index}
              className={`relative group cursor-pointer overflow-hidden rounded-xl ${
                index === 0 || index === 5 ? 'md:col-span-2 md:row-span-2' : ''
              }`}
              onClick={() => setSelectedImage(item.src)}
            >
              <div className={`relative overflow-hidden ${
                index === 0 || index === 5 ? 'h-[250px] md:h-[400px]' : 'h-[180px] md:h-[200px]'
              }`}>
                <img
                  src={item.src}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Zoom Icon */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-12 h-12 rounded-full bg-yellow-400 flex items-center justify-center">
                    <ZoomIn className="w-6 h-6 text-black" />
                  </div>
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <div className="flex items-center gap-2 mb-1">
                    <item.icon className="w-4 h-4 text-yellow-400" />
                    <span className="text-yellow-400 text-xs uppercase tracking-wider">
                      {item.category}
                    </span>
                  </div>
                  <h3 className="text-white font-semibold">{item.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="flex flex-wrap justify-center gap-4 mt-12">
          <div className="flex items-center gap-2 px-4 py-2 bg-green-600/20 border border-green-500/30 rounded-full">
            <Sparkles className="w-4 h-4 text-green-500" />
            <span className="text-green-500 text-sm font-medium">100% Pure Vegetarian</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-yellow-400/20 border border-yellow-400/30 rounded-full">
            <Hotel className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 text-sm font-medium">AC Rooms Available</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 border border-blue-500/30 rounded-full">
            <Car className="w-4 h-4 text-blue-500" />
            <span className="text-blue-500 text-sm font-medium">Safe Parking</span>
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X className="w-6 h-6 text-white" />
          </button>
          <img
            src={selectedImage}
            alt="Gallery Image"
            className="max-w-full max-h-[90vh] object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
};

export default Gallery;
