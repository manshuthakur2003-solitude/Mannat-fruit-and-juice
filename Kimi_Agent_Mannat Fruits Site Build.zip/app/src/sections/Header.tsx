import { useState, useEffect } from 'react';
import { Menu, X, Phone, Hotel, UtensilsCrossed, Info, Image, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about', icon: Info },
    { name: 'Menu', href: '#menu', icon: UtensilsCrossed },
    { name: 'Rooms', href: '#rooms', icon: Hotel },
    { name: 'Gallery', href: '#gallery', icon: Image },
    { name: 'Contact', href: '#contact', icon: MapPin },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-black/95 backdrop-blur-md shadow-lg shadow-black/20'
          : 'bg-transparent'
      }`}
    >
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a
            href="#"
            className="flex items-center gap-2 group"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <span className="text-black font-bold text-lg md:text-xl">M</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-white font-bold text-lg md:text-xl leading-tight">
                Mannat
              </h1>
              <p className="text-yellow-400 text-xs md:text-sm">Fruits & Juice</p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.href)}
                className="px-4 py-2 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 text-sm font-medium"
              >
                {link.name}
              </button>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <Button
              variant="outline"
              className="border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black"
              onClick={() => scrollToSection('#menu')}
            >
              <UtensilsCrossed className="w-4 h-4 mr-2" />
              View Menu
            </Button>
            <Button
              className="bg-yellow-400 text-black hover:bg-yellow-500"
              onClick={() => scrollToSection('#rooms')}
            >
              <Hotel className="w-4 h-4 mr-2" />
              Book Room
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-black/98 backdrop-blur-md border-t border-white/10">
          <nav className="flex flex-col p-4">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.href)}
                className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
              >
                <link.icon className="w-5 h-5 text-yellow-400" />
                {link.name}
              </button>
            ))}
            <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-white/10">
              <Button
                variant="outline"
                className="border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black w-full"
                onClick={() => scrollToSection('#menu')}
              >
                <UtensilsCrossed className="w-4 h-4 mr-2" />
                View Menu
              </Button>
              <Button
                className="bg-yellow-400 text-black hover:bg-yellow-500 w-full"
                onClick={() => scrollToSection('#rooms')}
              >
                <Hotel className="w-4 h-4 mr-2" />
                Book Room
              </Button>
              <a
                href="tel:+919617000044"
                className="flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-lg font-medium"
              >
                <Phone className="w-4 h-4" />
                Call Now
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
