import { useState } from 'react';
import { GlassWater, UtensilsCrossed, Flame, Coffee, ChevronRight } from 'lucide-react';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('juices');

  const categories = [
    { id: 'juices', name: 'Fresh Juices & Shakes', icon: GlassWater },
    { id: 'fastfood', name: 'Fast Food', icon: UtensilsCrossed },
    { id: 'maincourse', name: 'Main Course', icon: Flame },
    { id: 'breads', name: 'Breads', icon: Flame },
    { id: 'quickbites', name: 'Quick Bites & Tea', icon: Coffee },
  ];

  const menuItems = {
    juices: [
      { name: 'Mosambi Juice', prices: ['₹60', '₹80', '₹100'], sizes: ['Small', 'Medium', 'Large'] },
      { name: 'Mannat Special Mix Juice', prices: ['₹70', '₹90', '₹110'], sizes: ['Small', 'Medium', 'Large'] },
      { name: 'Anar Juice', prices: ['₹120', '₹150', '₹200'], sizes: ['Small', 'Medium', 'Large'] },
      { name: 'Kaju Milk Shake', prices: ['₹150'], sizes: ['Regular'] },
      { name: 'Banana Shake', prices: ['₹60', '₹80', '₹100'], sizes: ['Small', 'Medium', 'Large'] },
    ],
    fastfood: [
      { name: 'Veg Chowmein', prices: ['₹50', '₹90'], sizes: ['Half', 'Full'] },
      { name: 'Veg Burger', prices: ['₹40'], sizes: ['Regular'] },
      { name: 'Paneer Veg Burger', prices: ['₹60'], sizes: ['Regular'] },
      { name: 'Veg Steam Momos', prices: ['₹50'], sizes: ['8 pcs'] },
      { name: 'Veg Fried Momos', prices: ['₹60'], sizes: ['8 pcs'] },
      { name: 'Spring Roll', prices: ['₹50'], sizes: ['4 pcs'] },
      { name: 'French Fries', prices: ['₹50'], sizes: ['Regular'] },
      { name: 'Chilli Potato', prices: ['₹70'], sizes: ['Regular'] },
    ],
    maincourse: [
      { name: 'Dal Fry', prices: ['₹50', '₹80'], sizes: ['Half', 'Full'] },
      { name: 'Dal Makhani', prices: ['₹120', '₹200'], sizes: ['Half', 'Full'] },
      { name: 'Shahi Paneer', prices: ['₹180', '₹280'], sizes: ['Half', 'Full'] },
      { name: 'Kadhai Paneer', prices: ['₹180', '₹280'], sizes: ['Half', 'Full'] },
      { name: 'Mix Veg', prices: ['₹100', '₹170'], sizes: ['Half', 'Full'] },
    ],
    breads: [
      { name: 'Tandoor Roti', prices: ['₹10'], sizes: ['1 pc'] },
      { name: 'Butter Roti', prices: ['₹12'], sizes: ['1 pc'] },
      { name: 'Lachha Parantha', prices: ['₹35'], sizes: ['1 pc'] },
      { name: 'Butter Naan', prices: ['₹30'], sizes: ['1 pc'] },
      { name: 'Stuff Naan', prices: ['₹60'], sizes: ['1 pc'] },
    ],
    quickbites: [
      { name: 'Tea', prices: ['₹20'], sizes: ['Cup'] },
      { name: 'Coffee', prices: ['₹40'], sizes: ['Cup'] },
      { name: 'Masala Maggie', prices: ['₹39'], sizes: ['Regular'] },
      { name: 'Cheese Maggie', prices: ['₹79'], sizes: ['Regular'] },
      { name: 'Aloo Chaat', prices: ['₹50'], sizes: ['Regular'] },
      { name: 'Fruit Salad', prices: ['₹50'], sizes: ['Regular'] },
    ],
  };

  return (
    <section id="menu" className="relative py-20 lg:py-28 bg-gradient-to-b from-black via-gray-900 to-black overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '30px 30px'
        }} />
      </div>

      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-600/20 border border-green-500/30 rounded-full mb-4">
            <UtensilsCrossed className="w-4 h-4 text-green-500" />
            <span className="text-green-500 text-sm font-medium uppercase tracking-wider">
              Our Complete Menu
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Delicious Food & <span className="text-yellow-400">Fresh Juices</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Pure vegetarian dishes prepared with love and the finest ingredients
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-10">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center gap-2 px-4 sm:px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-yellow-400 text-black'
                  : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <category.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{category.name}</span>
              <span className="sm:hidden">{category.name.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Menu Content */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-gray-900/50 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden">
            {/* Category Header */}
            <div className="bg-gradient-to-r from-yellow-400/20 to-yellow-600/20 px-6 py-4 border-b border-white/10">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                {categories.find(c => c.id === activeCategory)?.icon && (
                  <span className="text-yellow-400">
                    {(() => {
                      const Icon = categories.find(c => c.id === activeCategory)?.icon;
                      return Icon ? <Icon className="w-5 h-5" /> : null;
                    })()}
                  </span>
                )}
                {categories.find(c => c.id === activeCategory)?.name}
              </h3>
            </div>

            {/* Menu Items */}
            <div className="divide-y divide-white/5">
              {menuItems[activeCategory as keyof typeof menuItems].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between px-6 py-4 hover:bg-white/5 transition-colors"
                >
                  <div className="flex-1">
                    <h4 className="text-white font-medium text-lg">{item.name}</h4>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {item.sizes.map((size, sizeIndex) => (
                        <span key={sizeIndex} className="text-xs text-gray-500">
                          {size}
                          {sizeIndex < item.sizes.length - 1 && ' •'}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 sm:gap-6">
                    {item.prices.map((price, priceIndex) => (
                      <div key={priceIndex} className="text-right">
                        <span className="text-yellow-400 font-bold text-lg">{price}</span>
                        {item.sizes[priceIndex] && (
                          <span className="text-xs text-gray-500 ml-1 hidden sm:inline">
                            ({item.sizes[priceIndex]})
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* View All CTA */}
          <div className="text-center mt-8">
            <button
              onClick={() => {
                const element = document.querySelector('#contact');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 text-yellow-400 hover:text-yellow-300 font-medium transition-colors"
            >
              View Full Menu at Restaurant
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Featured Images */}
        <div className="grid sm:grid-cols-2 gap-6 mt-12 max-w-4xl mx-auto">
          <div className="relative rounded-2xl overflow-hidden group">
            <img
              src="/images/juice-mix.jpg"
              alt="Fresh Juices"
              className="w-full h-[200px] object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white font-semibold">Fresh Juices</p>
              <p className="text-gray-300 text-sm">No Sugar, Only Khaand</p>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden group">
            <img
              src="/images/fast-food.jpg"
              alt="Fast Food"
              className="w-full h-[200px] object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white font-semibold">Chinese & Snacks</p>
              <p className="text-gray-300 text-sm">Hot & Crispy</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Menu;
