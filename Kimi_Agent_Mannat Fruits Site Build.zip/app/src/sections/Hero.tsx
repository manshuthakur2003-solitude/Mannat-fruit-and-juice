import { Button } from '@/components/ui/button';
import { Hotel, UtensilsCrossed, Leaf, Phone } from 'lucide-react';

const Hero = () => {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(/images/hero-bg.jpg)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/90" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12 pt-20 pb-12">
        <div className="max-w-5xl mx-auto text-center">
          {/* USP Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-600/90 backdrop-blur-sm rounded-full mb-6 animate-fade-in">
            <Leaf className="w-4 h-4 text-white" />
            <span className="text-white text-sm font-medium">
              NO SUGAR in juices, ONLY KHAAND (Raw Sugar) for better health
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight slide-up">
            Mannat Fruits & Juice
            <span className="block text-yellow-400 mt-2">
              The Sweet & Salty Experience on NH-44
            </span>
          </h1>

          {/* Sub-headline */}
          <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-8 slide-up" style={{ animationDelay: '0.1s' }}>
            <span className="text-green-400 font-medium">Pure Veg Family Restaurant</span>
            <span className="mx-3 text-yellow-400">|</span>
            <span className="text-orange-400 font-medium">Fresh Juice Bar</span>
            <span className="mx-3 text-yellow-400">|</span>
            <span className="text-blue-400 font-medium">Deluxe AC Rooms</span>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 slide-up" style={{ animationDelay: '0.2s' }}>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black px-8 py-6 text-lg font-semibold rounded-xl transition-all duration-300 w-full sm:w-auto"
              onClick={() => scrollToSection('#menu')}
            >
              <UtensilsCrossed className="w-5 h-5 mr-2" />
              View Menu
            </Button>
            <Button
              size="lg"
              className="bg-yellow-400 text-black hover:bg-yellow-500 px-8 py-6 text-lg font-semibold rounded-xl transition-all duration-300 w-full sm:w-auto pulse-gold"
              onClick={() => scrollToSection('#rooms')}
            >
              <Hotel className="w-5 h-5 mr-2" />
              Book A Room
            </Button>
          </div>

          {/* Quick Contact */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 slide-up" style={{ animationDelay: '0.3s' }}>
            <a
              href="tel:+919617000044"
              className="flex items-center gap-2 text-white hover:text-yellow-400 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <span className="text-lg font-medium">+91 96170 00044</span>
            </a>
            <span className="hidden sm:block text-gray-500">|</span>
            <p className="text-gray-400 text-sm">
              NH-44, Nangal Kheri, Panipat – 132103
            </p>
          </div>

          {/* Trust Badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-12 slide-up" style={{ animationDelay: '0.4s' }}>
            <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg">
              <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                <Leaf className="w-4 h-4 text-white" />
              </div>
              <span className="text-white text-sm font-medium">100% Pure Veg</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg">
              <div className="w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center">
                <Hotel className="w-4 h-4 text-black" />
              </div>
              <span className="text-white text-sm font-medium">AC Rooms @ ₹1000</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg">
              <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                <UtensilsCrossed className="w-4 h-4 text-white" />
              </div>
              <span className="text-white text-sm font-medium">24/7 Service</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-yellow-400 rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
