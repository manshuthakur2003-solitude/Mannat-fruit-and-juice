import { MapPin, Phone, Clock, Award, Leaf, ExternalLink, Navigation } from 'lucide-react';

const Footer = () => {
  const quickLinks = [
    { name: 'Home', href: '#' },
    { name: 'About Us', href: '#about' },
    { name: 'Our Menu', href: '#menu' },
    { name: 'Rooms', href: '#rooms' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  const menuCategories = [
    { name: 'Fresh Juices', href: '#menu' },
    { name: 'Special Thalis', href: '#thalis' },
    { name: 'Main Course', href: '#menu' },
    { name: 'Fast Food', href: '#menu' },
    { name: 'Breads', href: '#menu' },
    { name: 'Beverages', href: '#menu' },
  ];

  const scrollToSection = (href: string) => {
    if (href === '#') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contact" className="relative bg-gradient-to-b from-black to-gray-950 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Trust Banner */}
      <div className="relative z-10 border-b border-white/10">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-yellow-400/10 flex items-center justify-center">
                  <Award className="w-6 h-6 text-yellow-400" />
                </div>
                <div>
                  <p className="text-white font-semibold">MDH Masala</p>
                  <p className="text-gray-400 text-sm">Authentic Taste</p>
                </div>
              </div>
              <div className="hidden md:block w-px h-12 bg-white/10" />
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-yellow-400/10 flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <p className="text-white font-semibold">Fortune Oil</p>
                  <p className="text-gray-400 text-sm">Pure & Healthy</p>
                </div>
              </div>
              <div className="hidden md:block w-px h-12 bg-white/10" />
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-yellow-400/10 flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <p className="text-white font-semibold">Khaand Only</p>
                  <p className="text-gray-400 text-sm">No Refined Sugar</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-12 lg:py-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {/* Brand Column */}
            <div className="lg:col-span-1">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
                  <span className="text-black font-bold text-2xl">M</span>
                </div>
                <div>
                  <h3 className="text-white font-bold text-xl">Mannat</h3>
                  <p className="text-yellow-400 text-sm">Fruits & Juice</p>
                </div>
              </div>
              <p className="text-gray-400 mb-6">
                Your perfect stop on NH-44 for delicious pure veg food, fresh juices, 
                and comfortable AC rooms.
              </p>
              <div className="flex items-center gap-2 text-green-500">
                <Leaf className="w-5 h-5" />
                <span className="font-medium">100% Pure Vegetarian</span>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-white font-bold text-lg mb-6">Quick Links</h4>
              <ul className="space-y-3">
                {quickLinks.map((link, index) => (
                  <li key={index}>
                    <button
                      onClick={() => scrollToSection(link.href)}
                      className="text-gray-400 hover:text-yellow-400 transition-colors"
                    >
                      {link.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Menu Categories */}
            <div>
              <h4 className="text-white font-bold text-lg mb-6">Our Menu</h4>
              <ul className="space-y-3">
                {menuCategories.map((item, index) => (
                  <li key={index}>
                    <button
                      onClick={() => scrollToSection(item.href)}
                      className="text-gray-400 hover:text-yellow-400 transition-colors"
                    >
                      {item.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="text-white font-bold text-lg mb-6">Contact Us</h4>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-1" />
                  <p className="text-gray-400">
                    NH-44, Nangal Kheri,<br />
                    Panipat – 132103
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <div>
                    <a href="tel:+919617000044" className="text-gray-400 hover:text-white block">
                      +91 96170 00044
                    </a>
                    <a href="tel:+918950067275" className="text-gray-400 hover:text-white block">
                      +91 89500 67275
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-blue-500 flex-shrink-0" />
                  <p className="text-gray-400">Open 24/7</p>
                </div>
              </div>

              {/* Map Button */}
              <a
                href="https://www.google.com/maps/search/Mannat+Fruits+%26+Juice+Panipat"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-6 px-4 py-2 bg-yellow-400 text-black rounded-lg font-medium hover:bg-yellow-500 transition-colors"
              >
                <Navigation className="w-4 h-4" />
                Get Directions
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Google Map Embed */}
          <div className="mt-12 rounded-2xl overflow-hidden border border-white/10">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3491.0!2d76.96!3d29.39!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390c0!2sMannat+Fruits+%26+Juice!5e0!3m2!1sen!2sin!4v1600000000000"
              width="100%"
              height="300"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Mannat Fruits & Juice Location"
            />
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="relative z-10 border-t border-white/10">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 py-6">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm text-center md:text-left">
              © {new Date().getFullYear()} Mannat Fruits & Juice. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <span className="text-gray-500 text-sm">
                Pure Veg | Fresh Juices | AC Rooms
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
